
INIT_MESSAGE = 'Initializing...'